/*
 CheatSheet.playground
 Playground - noun: a place where people can play.
 
 Swift 4 Comprehensive Cheat Sheet and Quick Reference.
 Created by Dr. Mustafa Youldash on 06/05/2018.
 Inspired by the work of Ray Wenderlich <https://www.raywenderlich.com>.
 Copyright © 2018 KKUx. All rights reserved.
 
 Except where otherwise noted, this work is vested in KKUx <http://kkux.org> and is licensed under the
 Creative Commons Attribution-NonCommercial 4.0 International License <http://creativecommons.org/licenses/by-nc/4.0>.
 
 Unless otherwise stated, no part of this work may be reproduced and redistributed by any process, nor used for commercial purposes without the written permission of
 KKUx and the author.
 
 If you modify or build upon the work, you may only distribute the resulting work under the same license conditions as this one.
 */

import Foundation

/// Last checked with Version 11.2 (11B52).
#if swift(>=5.2)
print("Hello, Swift 5.2")

#elseif swift(>=5.1)
print("Hello, Swift 5.1")

#elseif swift(>=5.0)
print("Hello, Swift 5.0")

#elseif swift(>=4.2)
print("Hello, Swift 4.2")

#elseif swift(>=4.1)
print("Hello, Swift 4.1")

#elseif swift(>=4.0)
print("Hello, Swift 4.0")

#elseif swift(>=3.2)
print("Hello, Swift 3.2")

#elseif swift(>=3.0)
print("Hello, Swift 3.0")

#elseif swift(>=2.2)
print("Hello, Swift 2.2")

#elseif swift(>=2.1)
print("Hello, Swift 2.1")

#elseif swift(>=2.0)
print("Hello, Swift 2.0")

#elseif swift(>=1.2)
print("Hello, Swift 1.2")

#elseif swift(>=1.1)
print("Hello, Swift 1.1")

#elseif swift(>=1.0)
print("Hello, Swift 1.0")

print() // Separate by a newline.

#endif

/// Getting Version and Build Info with Swift
func version() -> String {
    let dictionary = Bundle.main.infoDictionary!
    let version = dictionary["CFBundleShortVersionString"] as! String
    let build = dictionary["CFBundleVersion"] as! String
    return "\(version) build \(build)"
}

version()

if let text = Bundle.main.infoDictionary?["CFBundleVersion"] as? String {
    print(text)
}

/* Language Basics. */

/*
 In Swift, you can use the underscore as a thousands separator.
 */
let trillion = 1_000_000_000_000 // i.e. a million million (1,000,000,000,000 or 10^12).

/// Variables can be updated.
var variableNumber: Int = 1
variableNumber = variableNumber + 1

/// Constants cannot be updated.
let constNumber: Int = 1
// constNumber = constNumber + 1 <- error!

/// Inferred type.
let inferredInt = 1

/// Swift types.
let int: Int = 20
let double: Double = 3.5
let float: Float = 4.5
let bool: Bool = false
var str: String = "Hello, Swift!"

/// Objective-C supportive types.
let anObj: NSObject? = nil
let anInt: NSInteger = 45
let aNumber: NSNumber = 9.0
let aBool: ObjCBool = true
var aStr: NSString = "Foo"

/// Explicit type conversion.
let pi = 3.1415
let multiplier = 2
let twoPi = pi * Double(multiplier)

/* Strings. */

var 🤓 = "Geek"
var 👨🏼‍💼 = "فلان"
var combinedString = "\(🤓) says مرحباً to \(👨🏼‍💼)!"
var tipString = "2499"
var tipInt = Int(tipString) // Casting.

tipString = "24.99"
var tipDouble = Double(tipString)

/// String API.
var string: String! = "Hello, Swift!"
string = string.lowercased(); print(string!)

/* You can check any optional type using an if statement. */
if string != nil {
    string = string.lowercased(); print(string!)
}

/// String API.
var greeting: String = "hello, world".capitalized
var alternateGreeting = greeting

alternateGreeting += " and beyond!"
print(alternateGreeting)

greeting.append(Character("!"))
print(greeting + "\n")

/* Basic Control Structures. */

for _ in 1..<3 {
    // Loops with index taking values 1,2.
}

for _ in 1...3 {
    // Loops with index taking values 1,2,3.
}

for _ in stride(from: 10, through: 20, by: 2) {
    // Loops from 10 to 20 (inclusive) in steps of 2.
}

var index = 0
while index < 5 {
    // Loops 5 times.
    index += 1 // ++
}

index = 0
repeat { // Loops 5 times.
    
    index += 1 // ++
} while index < 5

/// if/else.
let temperature = 45
if temperature > 60 {
    print("It's hot!")
} else if temperature > 40 {
    print("It's warm.")
} else {
    print("It's chilly.")
}

/// Control Flow.
var condition = true
if condition {
    // ...
    
} else { /* ... */ }

srandomdev() // Seed the random number generator.

// Omits upper value, use ... to include.
for _ in 0..<2 {
    print("\(arc4random())")
}

for i: Int in 0..<3 { print("i = \(i)") }

for j in 0..<3 { // Uses fast enumeration.
    
    print("j = \(j)")
}

/* Tuples. */

let tuple = (1, 3, 5) // Inferred type (Int, Int, Int).
let tuple2 = (1, 5.0) // Inferred type (Int, Double).
let tuple3: (Double, Double) = (5, 6)

/// Indexing a tuple.
print(tuple.0)
print(tuple.1)
print(tuple.2)

/// A tuple with named elements.
let product = (id: 24, name: "Swift Book")
print(product.name)

/// Decomposing a tuple.
let (x, y, z) = tuple
print("\(x), \(y), \(z)") // "1, 3, 5."

/*
 Tuples are a grouping of multiple values into a single type.
 Unlike classes and structs, however,
 you can create a tuple without explicitly defining the type.
 */
var address = (742, "Salam St.")
print(address.0)
print(address.1)

/* You can update the components of a tuple via the index notation, as follows: */
address.0 = 744

// Using a type annotation.
var address1: (Int, String) = (50, "Peace Rd.")

// By explicit creation of a Double.
var address2 = (Double(50), "Peace Rd.")

// By using a double literal value.
var address3 = (50.0, "Peace Rd.")

/* You can also deconstruct tuples into their individual elements. */
let (house, street) = address
print("House: " + String(house)) // Using string interpolation.
print("Street: " + street  + "\n")

/* Another way to work with tuples is to name their elements. */
var address4 = (number: 50, street: "Peace Rd.")
print("I live at \(address4.number), \(address4.street)")

/* Arrays. */

/// Empty array creation.
let emptyAr1 = [String]()
let emptyAr2 = Array<String>()
let emptyAr3: [String] = []

/// A constant array with inferred type.
let animals = ["cat", "dog", "chicken"]
// animals.append("cow") <- error!
// animals[2] = "fish" <- error!

/// A variable array with explicit type.
var mutableAnimals: [String] = ["cat", "dog", "chicken"]
mutableAnimals.append("cow")
mutableAnimals[2] = "fish"

/// Iteration.
for animal in animals { print(animal) }

/// Array API.
animals[0]                      // "cat."
animals[1..<3]                  // "dog", "chicken" "3."
animals.count                   // 3.
animals.contains("cat")         // true.
mutableAnimals.remove(at: 0)    // "cat."

/// Functional API.
animals.map { $0.uppercased() }         // "CAT", "DOG", ...
animals.filter { $0.hasPrefix("c") }    // true.
animals.sorted { $0 < $1 }              // false.

/// Bridged NSArray API.
let nsArray = animals as NSArray
nsArray.object(at: 2) // "chicken."

/// Arrays (Quick Examples).
var array1 = [1, 2, 3, 4, 5]
print(array1[2]); print()

var person1 = "فلان"
var person2 = "علان"
var array2: [String] = [person1, person2]

/* Adds (appends) a new element at the end of the array. */
array2.append("وليد")

/* You can even extend an array by adding a sequence to it, such as a range. */
//array1.extend(7...10)

for person in array2 {
    print("person: \(person)")
}

var waleed = array2[2]

/* Dictionaries. */

/// Empty dictionary creation.
let emptyDict1 = [Int:String]()
let emptyDict2 = Dictionary<Int, String>()
let emptyDict3: [Int:String] = [:]

/// A constant dictionary with inferred type.
let numbers = [1 : "One", 2 : "Two", 3 : "Three"] as NSDictionary
// numbers[4] = "Four" <- error!

/// A variable dictionary with explicit type.
var students: [String: String] = ["123": "Amal",
                                  "456": "Ahmed",
                                  "789": "Fahad"]

/// Unwrapping.
if let student = students["789"] {
    print("Student is \(student)")
}

/// Dictionary API.
students["789"]                     // "Fahad."
students["789"] = "Sarah"           // "Sarah."
students["1"]                       // "nil."
students.count                      // "3."
students.removeValue(forKey: "456") // Delete "Ahmed" OR students[456] = nil.

/// Dictionary values are returned as optionals.
students["789"]!.hasPrefix("s")     // true.

/// Iteration.
for (key, value) in students {
    print("Student[\(key)], : \(value)")
}

/* Sets. */

//var setA = Set<Int>()
var setA: Set = [1, 2, 3]
setA.insert(1)
print(setA)

setA.remove(1)
print(setA)

var setB: Set = [2, 4, 6]
print(setA.intersection(setB))

/* Optionals. */

/// An optional variable.
var maybeString: String?    // Defaults to nil.
maybeString = nil           // Can be assigned a nil.
maybeString = "fish"        // Can be assigned a value.

/// Unwrapping an optional.
if let unwrappedString = maybeString {
    // "unwrappedString" is a String rather than an optional String.
    print(unwrappedString.hasPrefix("f")) // true.
} else {
    print("maybeString is nil.")
}

/// Forced unwrapping - fails at runtime if the optional is nil.
if maybeString!.hasPrefix("f") {
    print("maybeString starts with 'f'")
}

/*
 Optional chaining, returning an optional with the result of hasPrefix,
 which is then unwrapped.
 */
if let hasPrefix = maybeString?.hasPrefix("f") {
    if hasPrefix {
        print("maybeString starts with 'f'")
    }
}

/// Unwrapping of multiple optionals.
let strOne: String? = "256"
let digitOne: Int? = Int(strOne!) // Swift 1.x used "strOne.toInt()."
let strTwo: String? = "123"
let digitTwo: Int? = Int(strTwo!) // Swift 1.x used "strOne.toInt()."

/// NSString API.
let strThree: NSString = "123"
let one23: Int = Int(strThree.intValue)

/// Optional chaining.
var optionalPi: Double? = nil /*Using forced unwrapping.*/
optionalPi = 3.14159

print("Force unwrapped! \(optionalPi!)" + "\n")

if let definiteDouble = optionalPi {
    definiteDouble
}

if let digitOne = digitOne, let digitTwo = digitTwo {
    /*
     Notice that digitOne and digitTwo are local constants of type Int
     that 'shadow' the constants of type Int? that were initialized earlier.
     */
    print(digitOne + digitTwo)
}

/// Optional unwrapping with conditions.
if let digitOne = digitOne,
    let digitTwo = digitTwo,
    digitTwo != 5 {
    
    print(digitOne + digitTwo)
}

/// "nil" coalescing.
var anOptional: Int?
var coalesced = anOptional ?? 3 // "nil" value coalesced to 3.

/* Implicitly Unwrapped Optionals. */

/// An implicitly unwrapped optional variable.
var optionalString: String!
optionalString = nil
optionalString = "fish"

/// Methods invoked directly, failing at runtime if the optional is nil.
if optionalString.hasPrefix("f") {
    print("maybeString starts with 'f'")
} else {
    print("maybeString does not start with an 'f'")
}

/* Enums. */

/// Enum declaration.
enum Direction { case North, South, East, West }

/// Assignment.
var direction = Direction.North
direction = .South // Enum type inferred.

/// Switching on enums.
switch direction {
case .North:
    print("Going North.")
default:
    print("Going someplace else!")
}

/// Advanced enumerations - using generics.
enum Result<T> {
    case Failure
    // Enumeration member with associated value.
    case Success(T)
}

/// Creating an instance - where the type T is an Int.
var result = Result.Success(22)

/// Switching and extracting the associated value.
switch result {
    case .Failure:
        print("Operation failed.")
    case .Success(let value):
        print("Operation returned value \(value).")
}

/// Assignment (using data types.)
enum EdgeType: Int {
    case directed = 1
    case undirected = 2
}
var type = EdgeType.undirected

/* Switch. */

enum Bit { case Zero, One }
let bit = Bit.Zero

/// A simple switch statement on an enum.
switch bit {
case .Zero:
    print("zero")
case .One:
    print("one")
}

/// Interval matching.
let time = 45
switch time {
case 0..<60:
    print("A few seconds ago.")
case 60..<(60 * 4):
    print("A few minutes ago.")
default: // Default required in order.
    print("Ages ago!") // To be exhaustive
}

/// Tuples and value bindings.
let boardLocation = (2, 5)
switch boardLocation {
    
case (3, 4), (3, 3), (4, 3), (4, 4):
    print("Central location.")
    
case (let x, let y):
    print("(\(x), \(y)) is not in the center.")
    
} /* Note: switch cases must be exhaustive and cover all possible cases. */

/* Functions/Methods. */

/// A simple function.
func display(message: String) {
    print(message)
}
display(message: "Hello, Swift!")

/// A function that returns a value.
func multiply(arg1: Double, arg2: Double) -> Double {
    return arg1 * arg2
}
let val = multiply(arg1: 20.0, arg2: 35.2)

/// Another example.
///
/// - Parameters:
///   - s1: 1st parameter.
///   - s2: 2nmd parameter.
///   - joiner: 3rd parameter.
/// - Returns: A joined string,
func join(string s1: String,
          toString s2: String,
          withJoiner joiner: String) -> String {
    return s1 + joiner + s2
}
join(string: "Hello", toString: "Swift!", withJoiner: ", ")

/// Our three parameters now have these external and local names:
///
///  - external message, local: message.
///  - external: withPrefix, local: prefix.
///  - external: andSuffix, local: suffix.
func logMessage(message:String,
                withPrefix prefix: NSString,
                andSuffix suffix: NSString) {
    print("\(prefix)-\(message)-\(suffix)")
}
logMessage(message: "QWERTY", withPrefix: "***", andSuffix: "$$$")

/// in-out parameters.
///
/// - Parameter number: A parameter.
func square(_ number: inout Double) {
    number *= number
}
var number = 4.0
square(&number) // number = 16.

/// Function types.
let myFunc: (Double, Double) -> Double = multiply

/// A generic function.
func areEqual<T: Equatable>(op1: T, op2: T) -> Bool {
    return op1 == op2
}

/* Closures. */

let degrees = ["Bachelor", "Master", "PhD"]

degrees.sorted {
    (one: String, two: String) -> Bool in
    return one > two
}

/// Inferred argument type.
degrees.sorted {
    (one, two) -> Bool in
    return one > two
}

/// Inferred return type.
degrees.sorted {
    (one, two) in
    return one > two
}

/// No brackets around parameters.
degrees.sorted {
    one, two in
    return one > two
}

/// No return keyword.
degrees.sorted {
    one, two in
    one > two
}

/// Shorthand arguments.
degrees.sorted { $0 > $1 }

/// Trailing closure.
degrees.sorted() { $0 > $1 }
degrees.sorted { $0 > $1 }

/* Classes and Protocols. */

/// Base class implementation.
public class BaseClass {
    
    /// Private constant property.
    let id: Int
    
    init(id: Int) { self.id = id }
}

/// Protocols.
protocol NamedType {
    
    /// A property with a getter.
    var name: String { get }
}

/// Class implementation.
class Student: BaseClass, NamedType {
    
    /// Variable with public getter and private setter.
    private(set) var name: String
    
    /// Implicit internal property.
    var size: Double = 45.0
    
    /// Public constant property.
    public let fullName: String
    
    /// All properties initialized before base init invoked.
    ///
    /// - Parameters:
    ///   - id: Student id.
    ///   - name: Student name.
    ///   - fullName: Student full name.
    init(id: Int, name: String, fullName: String) {
        
        self.name = name
        self.fullName = fullName
        
        // "super" initializer invoked.
        super.init(id: id)
        
        /* Functions on self can now be called. */
    }
}

/// Creating an instance.
var student = Student(id: 140101, name: "Foo", fullName: "Foo, son of Foo")

/// Another abstract (base) class.
class AbstractClass { /* ... */ }

/// Protocols.
protocol OptionalProtocol1 {}
protocol OptionalProtocol2 {

    /// Tells whether an object is updated or not.
    var updated: Bool? { get set }

    /// Sample method with parameters.
    ///
    /// - Parameters:
    ///   - a: A variable.
    ///   - b: Another variable.
    func addUp(_ a: Float, b: Float) -> Double
}

/// Subclass implementation.
class MySubclass : AbstractClass, OptionalProtocol1, OptionalProtocol2 {

    /* Property declarations. */
    var myProperty: String
    var myOptionalProperty: String?
    // More properties...

    /// Tells whether an object is uppdated or not.
    var updated: Bool? = false

    /// Only need override if subclassing.
    override init()  {
        myProperty = "Foo"
    }

    /* Functions. */

    /// A function dubbed "compute()."
    ///
    /// - Returns: An integer.
    func compute() -> Int { return 0 }

    func compute(a: Int) -> Int {
        return a
    }

    func compute(a: Int, b: Int) -> Int {
        return a + b
    }

    func compute(a: Int, and b: Int) -> Int {
        return a + b
    }
    
    /// Sample method with parameters.
    ///
    /// - Parameters:
    ///   - a: A variable.
    ///   - b: Another variable.
    /// - Returns: A boolean value.
    func addUp(_ a: Float, b: Float) -> Double {
        return Double(a * b)
    }
}

/// Creating an instance.
var a = MySubclass()
a.myProperty
a.compute()
a.compute(a: 1)
a.compute(a: 2, b:3)
a.compute(a: 2, and: 3)

let b = a.compute(a: 2, and: 3) as Int
print("2 + 3 = \(b)")
